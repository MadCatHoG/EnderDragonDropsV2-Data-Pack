# Ender Dragon Drops v2 Data Pack

After killing the ender dragon a new egg will spawn on top of the end portal and an Elytra on top of that.

Works on Minecraft 1.13 to 1.16+

## Changelog

- Updated animation
- Updated meta data to show compatibility with Minecraft 1.16
- Added pack image
- Added a new release file
